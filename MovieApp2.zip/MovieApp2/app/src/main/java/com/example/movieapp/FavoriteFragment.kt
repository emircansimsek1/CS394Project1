package com.example.movieapp

class FavoriteFragment {
}